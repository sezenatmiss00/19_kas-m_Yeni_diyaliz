-- ============================================================================
-- KOCAELİ ÜNİVERSİTESİ HEMODİYALİZ ÜNİTESİ - ORACLE HBYS VIEW ŞEMASI
-- GÜNCELLEME: 2026-11-12T14:12:11.956998
-- ============================================================================

CREATE TABLE hasta_bilgileri (
    hastano VARCHAR2(20) PRIMARY KEY,
    adi     VARCHAR2(50) NOT NULL,
    soyadi  VARCHAR2(50) NOT NULL
);

CREATE TABLE dyz_hasta_bilgileri (
    hastadiyalizrefno NUMBER PRIMARY KEY,
    hastano           VARCHAR2(20) NOT NULL REFERENCES hasta_bilgileri(hastano)
);

CREATE TABLE dyz_hasta_tedavi_bilgileri (
    hastatedavirefno  NUMBER PRIMARY KEY,
    hastadiyalizrefno NUMBER NOT NULL REFERENCES dyz_hasta_bilgileri(hastadiyalizrefno)
);

CREATE TABLE dyz_hasta_seanslari (
    HASTASEANSREFNO     NUMBER PRIMARY KEY,
    HASTATEDAVIREFNO    NUMBER NOT NULL REFERENCES dyz_hasta_tedavi_bilgileri(hastatedavirefno),
    KABULTARIHI         DATE,
    HASTABASVURUREFNO   NUMBER,
    HASTAHIZMETREFNO    NUMBER,
    SEANSTARIHI         DATE,
    VARDIYATANIMNO      NUMBER(1) DEFAULT 1,
    SEANSTURU           VARCHAR2(30) DEFAULT 'HEMODIYALIZ',
    SURE                NUMBER(4) DEFAULT 180,
    BASVURUTURU         VARCHAR2(30) DEFAULT 'PLANLANDI',
    KABULIPTALNEDENNO   NUMBER,
    KABULIPTALTARIHI    DATE,
    kabuliptalaciklama  VARCHAR2(500),
    IPTALEDENP          VARCHAR2(50),
    IPTALTARIHI         DATE,
    STATU               VARCHAR2(30) DEFAULT 'BEKLEMEDE',
    completed_at        TIMESTAMP
);

CREATE OR REPLACE VIEW VW_DYZ_GUNLUK_HASTA_SEANSLARI AS
SELECT hb.adi || ' ' || hb.soyadi AS HASTAADI,
       dhb.hastano,
       t.HASTASEANSREFNO,
       t.HASTATEDAVIREFNO,
       t.KABULTARIHI,
       t.HASTABASVURUREFNO,
       t.HASTAHIZMETREFNO,
       t.SEANSTARIHI,
       CASE WHEN t.VARDIYATANIMNO = 1 THEN 'SABAH' ELSE 'ÖGLEN' END AS VARDIYA,
       t.SEANSTURU,
       t.SURE,
       t.BASVURUTURU,
       t.KABULIPTALNEDENNO,
       t.KABULIPTALTARIHI,
       t.kabuliptalaciklama,
       t.IPTALEDENP,
       t.IPTALTARIHI,
       t.STATU,
       t.completed_at
  FROM dyz_hasta_seanslari t
  LEFT JOIN dyz_hasta_tedavi_bilgileri dhtb
    ON t.hastatedavirefno = dhtb.hastatedavirefno
  LEFT JOIN dyz_hasta_bilgileri dhb
    ON dhtb.hastadiyalizrefno = dhb.hastadiyalizrefno
  LEFT JOIN hasta_bilgileri hb ON dhb.hastano = hb.hastano
 WHERE (t.STATU != 'COMPLETED' OR t.completed_at IS NULL OR t.completed_at >= SYSTIMESTAMP - INTERVAL '2' MINUTE);
